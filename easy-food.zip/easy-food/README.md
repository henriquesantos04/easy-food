# Easy Food MVP
Plataforma simples para conectar prestadores de serviços culinários com clientes.